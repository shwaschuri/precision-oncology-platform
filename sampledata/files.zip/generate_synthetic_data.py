"""
Generate synthetic TCGA-like data for demonstration and GitHub upload.
Run: python3 generate_synthetic_data.py
Produces:
  data/synthetic_mutations.csv   -- MAF-like mutation data (50 samples, ~8000 mutations)
  data/synthetic_tmb_scores.csv  -- Pre-computed TMB scores
  data/synthetic_clinical.csv    -- Clinical/survival data
  data/synthetic_expression.csv  -- RNA expression (for multi-omics demo)
  data/synthetic_cnv.csv         -- Copy number variation
"""

import pandas as pd
import numpy as np
from pathlib import Path

np.random.seed(42)
Path("data").mkdir(exist_ok=True)

# ─────────────────────────────────────────────
# CONFIG
# ─────────────────────────────────────────────

N_SAMPLES    = 50
CANCER_TYPE  = "TCGA-LUAD"
EXOME_MB     = 38.0

VARIANT_CLASSIFICATIONS = [
    "Missense_Mutation", "Missense_Mutation", "Missense_Mutation",  # most common
    "Nonsense_Mutation",
    "Frame_Shift_Del", "Frame_Shift_Ins",
    "In_Frame_Del", "In_Frame_Ins",
    "Splice_Site",
    "Silent", "Silent",                                             # non-coding
    "3'UTR", "5'UTR", "Intron",
]

CHROMOSOMES = [str(i) for i in range(1, 23)] + ["X", "Y"]

DRIVER_GENES_WEIGHTS = {
    "TP53":   0.50,
    "KRAS":   0.30,
    "EGFR":   0.20,
    "STK11":  0.18,
    "KEAP1":  0.17,
    "NF1":    0.12,
    "BRAF":   0.10,
    "PIK3CA": 0.09,
    "RB1":    0.08,
    "CDKN2A": 0.08,
    "SMAD4":  0.07,
    "PTEN":   0.07,
    "MET":    0.06,
    "ERBB2":  0.05,
    "ALK":    0.04,
    "RET":    0.03,
    "BRCA1":  0.04,
    "BRCA2":  0.04,
    "MLH1":   0.03,
    "MSH2":   0.02,
    "MSH6":   0.02,
    "PMS2":   0.02,
    "POLE":   0.02,
    "IDH1":   0.02,
    "ARID1A": 0.08,
    "KMT2D":  0.06,
}

BACKGROUND_GENES = [
    "TTN","MUC16","OBSCN","AHNAK2","SYNE1","FLG","MUC5B","DNAH17",
    "DNAH11","FSIP2","PKHD1","SYNE2","DNAH5","COL6A3","PCLO",
    "RYR2","CSMD3","FAT4","LRP1B","ZFHX4","DNAH8","CNTNAP2",
    "CACNA1E","HYDIN","MUC4","DNAH3","USH2A","DNAH2","HMCN1",
]

PROTEIN_CHANGES_BY_GENE = {
    "TP53":  ["p.R175H","p.R248W","p.R248Q","p.R273H","p.G245S","p.R249S","p.Y220C","p.H179R"],
    "KRAS":  ["p.G12C","p.G12D","p.G12V","p.G13D","p.Q61H","p.A146T"],
    "EGFR":  ["p.L858R","p.E746_A750del","p.T790M","p.L747_P753del","p.G719A"],
    "BRAF":  ["p.V600E","p.V600K","p.G469A","p.D594N"],
    "PIK3CA":["p.E545K","p.H1047R","p.E542K","p.H1047L"],
    "PTEN":  ["p.R130Q","p.R173C","p.C124S"],
    "STK11": ["p.Q37*","p.E199*","p.F354L"],
    "BRCA1": ["p.E1694*","p.Q1756*","p.L1764P"],
    "BRCA2": ["p.K2729N","p.S2835*","p.I2490T"],
    "MLH1":  ["p.V384D","p.K618A","p.R217C"],
    "POLE":  ["p.P286R","p.V411L","p.S459F"],
}

TUMOR_STAGES = ["stage ia","stage ib","stage iia","stage iib","stage iiia","stage iiib","stage iv"]

# ─────────────────────────────────────────────
# SAMPLE IDs
# ─────────────────────────────────────────────

def make_sample_id(i):
    return f"TCGA-SY-{1000+i:04d}-01A-11D-SYNTH-08"

sample_ids = [make_sample_id(i) for i in range(N_SAMPLES)]

# ─────────────────────────────────────────────
# ASSIGN SAMPLE PHENOTYPES
# ─────────────────────────────────────────────
# Give each sample a TMB profile: low / medium / high / ultramutator
phenotypes = np.random.choice(
    ["low","medium","high","ultra"],
    size=N_SAMPLES,
    p=[0.45, 0.35, 0.15, 0.05]
)

TMB_PROFILE = {
    "low":    (20,  60),
    "medium": (60,  200),
    "high":   (200, 500),
    "ultra":  (500, 1200),
}

# ─────────────────────────────────────────────
# GENERATE MUTATIONS
# ─────────────────────────────────────────────

print("Generating synthetic mutations...")
rows = []

for i, sample in enumerate(sample_ids):
    ph       = phenotypes[i]
    n_lo, n_hi = TMB_PROFILE[ph]
    n_muts   = np.random.randint(n_lo, n_hi)

    # Driver gene mutations
    for gene, prob in DRIVER_GENES_WEIGHTS.items():
        if np.random.random() < prob:
            protein = np.random.choice(PROTEIN_CHANGES_BY_GENE.get(gene, ["p.R100Q"]))
            chrom   = np.random.choice(CHROMOSOMES)
            pos     = np.random.randint(1_000_000, 250_000_000)
            depth   = np.random.randint(30, 300)
            alt_cnt = int(depth * np.random.uniform(0.1, 0.6))
            rows.append({
                "Hugo_Symbol":           gene,
                "Chromosome":            chrom,
                "Start_Position":        pos,
                "End_Position":          pos + np.random.randint(0, 5),
                "Variant_Classification":"Missense_Mutation",
                "Variant_Type":          "SNP",
                "Reference_Allele":      np.random.choice(["A","C","G","T"]),
                "Tumor_Seq_Allele1":     np.random.choice(["A","C","G","T"]),
                "Tumor_Seq_Allele2":     np.random.choice(["A","C","G","T"]),
                "Tumor_Sample_Barcode":  sample,
                "HGVSp_Short":           protein,
                "HGVSc":                 f"c.{np.random.randint(100,3000)}A>G",
                "t_depth":               depth,
                "t_alt_count":           alt_cnt,
            })

    # Background mutations
    n_background = max(0, n_muts - len([r for r in rows if r["Tumor_Sample_Barcode"] == sample]))
    for _ in range(n_background):
        gene  = np.random.choice(BACKGROUND_GENES)
        vtype = np.random.choice(VARIANT_CLASSIFICATIONS)
        chrom = np.random.choice(CHROMOSOMES)
        pos   = np.random.randint(1_000_000, 250_000_000)
        depth = np.random.randint(20, 400)
        alt   = int(depth * np.random.uniform(0.05, 0.7))
        rows.append({
            "Hugo_Symbol":           gene,
            "Chromosome":            chrom,
            "Start_Position":        pos,
            "End_Position":          pos + np.random.randint(0, 10),
            "Variant_Classification":vtype,
            "Variant_Type":          np.random.choice(["SNP","DEL","INS"]),
            "Reference_Allele":      np.random.choice(["A","C","G","T"]),
            "Tumor_Seq_Allele1":     np.random.choice(["A","C","G","T"]),
            "Tumor_Seq_Allele2":     np.random.choice(["A","C","G","T"]),
            "Tumor_Sample_Barcode":  sample,
            "HGVSp_Short":           f"p.{np.random.choice(list('ACDEFGHIKLMNPQRSTVWY'))}{np.random.randint(1,500)}{np.random.choice(list('ACDEFGHIKLMNPQRSTVWY'))}",
            "HGVSc":                 f"c.{np.random.randint(1,5000)}A>T",
            "t_depth":               depth,
            "t_alt_count":           alt,
        })

    if (i + 1) % 10 == 0:
        print(f"  {i+1}/{N_SAMPLES} samples done")

mut_df = pd.DataFrame(rows)
mut_df.to_csv("data/synthetic_mutations.csv", index=False)
print(f"Saved data/synthetic_mutations.csv  ({len(mut_df):,} mutations, {N_SAMPLES} samples)")

# ─────────────────────────────────────────────
# COMPUTE TMB SCORES
# ─────────────────────────────────────────────

print("Computing TMB scores...")
TMB_COUNTED = [
    "Missense_Mutation","Nonsense_Mutation","Frame_Shift_Del","Frame_Shift_Ins",
    "In_Frame_Del","In_Frame_Ins","Splice_Site","Translation_Start_Site","Nonstop_Mutation",
]
df_coding = mut_df[mut_df["Variant_Classification"].isin(TMB_COUNTED)]
tmb_df = df_coding.groupby("Tumor_Sample_Barcode").size().reset_index(name="mutation_count")
tmb_df.rename(columns={"Tumor_Sample_Barcode":"sample_id"}, inplace=True)
tmb_df["TMB"] = (tmb_df["mutation_count"] / EXOME_MB).round(2)
tmb_df["TMB_category"] = pd.cut(
    tmb_df["TMB"],
    bins=[0, 6, 16, float("inf")],
    labels=["Low (<6)","Medium (6-16)","High (>16)"]
)
tmb_df.to_csv("data/synthetic_tmb_scores.csv", index=False)
print(f"Saved data/synthetic_tmb_scores.csv")

# ─────────────────────────────────────────────
# CLINICAL / SURVIVAL DATA
# ─────────────────────────────────────────────

print("Generating clinical data...")
clin_rows = []
for i, sample in enumerate(sample_ids):
    ph        = phenotypes[i]
    stage_idx = np.random.randint(0, len(TUMOR_STAGES))
    stage     = TUMOR_STAGES[stage_idx]
    age       = np.random.randint(40, 82)
    gender    = np.random.choice(["Male","Female"])

    # Survival: high TMB / early stage = better prognosis
    base_os   = max(100, 2000 - stage_idx * 250 + np.random.randint(-200, 200))
    if ph in ("high","ultra"):
        base_os = int(base_os * np.random.uniform(1.1, 1.5))

    vital_status = np.random.choice(["Dead","Alive"], p=[0.45, 0.55])
    if vital_status == "Dead":
        days_to_death   = int(np.random.exponential(base_os))
        days_to_last_fu = None
    else:
        days_to_death   = None
        days_to_last_fu = int(base_os + np.random.randint(0, 500))

    clin_rows.append({
        "sample_id":             sample,
        "vital_status":          vital_status,
        "days_to_death":         days_to_death,
        "days_to_last_followup": days_to_last_fu,
        "age_at_diagnosis":      age,
        "tumor_stage":           stage,
        "gender":                gender,
        "cancer_type":           CANCER_TYPE,
        "TMB_phenotype":         ph,
    })

clin_df = pd.DataFrame(clin_rows)
clin_df.to_csv("data/synthetic_clinical.csv", index=False)
print(f"Saved data/synthetic_clinical.csv")

# ─────────────────────────────────────────────
# RNA EXPRESSION (for multi-omics demo)
# ─────────────────────────────────────────────

print("Generating synthetic RNA expression...")
IMMUNE_GENES = [
    "CD274","PDCD1","CTLA4","CD8A","CD8B","FOXP3","TIGIT","LAG3","HAVCR2",
    "GZMB","PRF1","IFNG","TNF","IL2","CD4","CD3E","CD19","CD56",
]
PATHWAY_GENES = [
    "EGFR","KRAS","BRAF","PIK3CA","PTEN","MYC","CCND1","CDK4","CDK6",
    "RB1","TP53","MDM2","BCL2","BCL2L1","BAX","CASP3","CASP8","CASP9",
]
OTHER_GENES   = [f"GENE_{i:04d}" for i in range(1, 33)]
ALL_GENES     = IMMUNE_GENES + PATHWAY_GENES + OTHER_GENES

expr_data = {}
for gene in ALL_GENES:
    base = np.random.lognormal(mean=2.0, sigma=1.2, size=N_SAMPLES)
    expr_data[gene] = base

# Make immune genes higher in high-TMB samples
tmb_vals = tmb_df.set_index("sample_id")["TMB"]
for s_idx, sample in enumerate(sample_ids):
    tmb_val = tmb_vals.get(sample, 5.0)
    for gene in IMMUNE_GENES:
        expr_data[gene][s_idx] *= (1 + tmb_val / 20)

expr_df = pd.DataFrame(expr_data, index=sample_ids)
expr_df.index.name = "sample_id"
expr_df = expr_df.round(3)
expr_df.to_csv("data/synthetic_expression.csv")
print(f"Saved data/synthetic_expression.csv  ({len(ALL_GENES)} genes)")

# ─────────────────────────────────────────────
# COPY NUMBER VARIATION
# ─────────────────────────────────────────────

print("Generating synthetic CNV data...")
CNV_GENES = [
    "MYC","EGFR","ERBB2","CCND1","CDK4","CDK6","MDM2","KRAS",
    "PIK3CA","AKT1","AKT2","PTEN","RB1","CDKN2A","TP53","BRCA1","BRCA2",
    "STK11","KEAP1","NF1","FGFR1","FGFR2","FGFR3","MET","ALK",
]
cnv_data = {}
for gene in CNV_GENES:
    # Log2 copy ratio centered around 0 (diploid)
    cnv = np.random.normal(loc=0, scale=0.8, size=N_SAMPLES)
    # Occasional focal amplifications and deletions
    amp_idx = np.random.choice(N_SAMPLES, size=max(1, N_SAMPLES//10), replace=False)
    del_idx = np.random.choice(N_SAMPLES, size=max(1, N_SAMPLES//10), replace=False)
    cnv[amp_idx] += np.random.uniform(1.5, 3.5, size=len(amp_idx))
    cnv[del_idx] -= np.random.uniform(1.0, 2.5, size=len(del_idx))
    cnv_data[gene] = cnv.round(3)

cnv_df = pd.DataFrame(cnv_data, index=sample_ids)
cnv_df.index.name = "sample_id"
cnv_df.to_csv("data/synthetic_cnv.csv")
print(f"Saved data/synthetic_cnv.csv  ({len(CNV_GENES)} genes)")

# ─────────────────────────────────────────────
# SUMMARY
# ─────────────────────────────────────────────

print("\n" + "=" * 50)
print("SYNTHETIC DATA GENERATION COMPLETE")
print("=" * 50)
print(f"Samples:           {N_SAMPLES}")
print(f"Total mutations:   {len(mut_df):,}")
print(f"Median TMB:        {tmb_df['TMB'].median():.2f} mut/Mb")
print(f"TMB-High samples:  {(tmb_df['TMB'] > 16).sum()}")
print(f"TMB-Med samples:   {((tmb_df['TMB'] >= 6) & (tmb_df['TMB'] <= 16)).sum()}")
print(f"TMB-Low samples:   {(tmb_df['TMB'] < 6).sum()}")
print()
print("Files created:")
print("  data/synthetic_mutations.csv    -- upload to GitHub as demo MAF")
print("  data/synthetic_tmb_scores.csv   -- pre-computed TMB (auto-loaded by dashboard)")
print("  data/synthetic_clinical.csv     -- survival data for Page 3")
print("  data/synthetic_expression.csv   -- RNA expression for Page 9 multi-omics")
print("  data/synthetic_cnv.csv          -- copy number for Page 9 multi-omics")
print()
print("To use in dashboard:")
print("  cp data/synthetic_mutations.csv data/TCGA-LUAD_merged.csv")
print("  cp data/synthetic_tmb_scores.csv data/tmb_scores.csv")
